@echo off
title DukenAI
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 goto nonode
node -e "process.exit(Number(process.versions.node.split('.')[0]) >= 18 ? 0 : 1)"
if errorlevel 1 goto oldnode

rem Dependencies ship with the project; install only if the folder was removed.
if not exist "node_modules\express\package.json" (
  echo Installing dependencies, one time only...
  call npm ci --omit=dev --no-audit --no-fund
  if errorlevel 1 goto failed
)

echo Starting DukenAI. The browser opens by itself.
node server.js
goto failed

:nonode
echo Node.js is not installed. Install the LTS version from nodejs.org, then double-click this file again.
start "" https://nodejs.org/en/download
goto failed

:oldnode
echo Your Node.js is too old. Install the LTS version from nodejs.org, then double-click this file again.
start "" https://nodejs.org/en/download

:failed
echo.
pause

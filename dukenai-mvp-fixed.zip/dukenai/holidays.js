// Calendar dates only; government decrees that move individual working days are not included.
// https://egov.kz/cms/ru/articles/holidays-calend
// Kurban Ait 2026: https://www.muftiyat.kz/ru/news/qmdb/2026-05-18/48344-27-maya---pervyij-den-prazdnika-kurban-ajt/
const FIXED = {
  '01-01': 'New Year', '01-02': 'New Year', '01-07': 'Orthodox Christmas',
  '03-08': 'March 8', '03-21': 'Nauryz', '03-22': 'Nauryz', '03-23': 'Nauryz',
  '05-01': 'Unity Day', '05-07': 'Defender of the Fatherland Day', '05-09': 'Victory Day',
  '07-06': 'Capital City Day', '08-30': 'Constitution Day', '10-25': 'Republic Day',
  '12-16': 'Independence Day'
};
const MOVABLE = { '2026-05-27': 'Kurban Ait' };
const BOOSTED = new Set(['New Year', 'Nauryz', 'Kurban Ait', 'March 8']);
// Religious holidays are not moved when they fall on a weekend (Labor Code of Kazakhstan, art. 85).
const RELIGIOUS = new Set(['Orthodox Christmas', 'Kurban Ait']);
const DAY = 86400000;
const shift = (date, n) => new Date(Date.parse(date + 'T12:00:00Z') + n * DAY).toISOString().slice(0, 10);
const isWeekend = date => [0, 6].includes(new Date(date + 'T12:00:00Z').getUTCDay());
const holidayName = date => MOVABLE[date] || FIXED[date.slice(5)] || null;
export function holiday(date) {
  const name = holidayName(date);
  return { name, boost: BOOSTED.has(name), lunarCalendarKnown: date.startsWith('2026-') };
}
// Non-working day: weekend, public holiday, or the working day that takes over a holiday falling on a
// weekend (e.g. Republic Day on Sunday 25 Oct 2026 makes Monday 26 Oct a day off).
export function dayOff(date) {
  const moved = [];
  for (let i = 21; i >= 0; i--) {
    const d = shift(date, -i), name = holidayName(d), weekend = isWeekend(d);
    let off = weekend || Boolean(name), from = null;
    if (weekend && name && !RELIGIOUS.has(name)) moved.push(name);
    else if (!off && moved.length) { off = true; from = moved.shift(); }
    if (i === 0) return { off, weekend, holiday: name, movedFrom: from };
  }
}
export const isPayday = date => [5, 20].includes(Number(date.slice(8, 10)));

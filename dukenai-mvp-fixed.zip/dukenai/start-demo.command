#!/bin/bash
# macOS: double-click in Finder. Linux: run ./start-demo.command
cd "$(dirname "$0")" || exit 1
finish() { echo; read -r -p "Press Enter to close this window..." _; exit 1; }
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Install the LTS version from https://nodejs.org, then open this file again."
  (open https://nodejs.org/en/download || xdg-open https://nodejs.org/en/download) >/dev/null 2>&1
  finish
fi
if ! node -e "process.exit(Number(process.versions.node.split('.')[0]) >= 18 ? 0 : 1)"; then
  echo "Your Node.js is too old. Install the LTS version from https://nodejs.org, then open this file again."
  finish
fi
# Dependencies ship with the project; install only if the folder was removed.
if [ ! -f node_modules/express/package.json ]; then
  echo "Installing dependencies, one time only..."
  npm ci --omit=dev --no-audit --no-fund || finish
fi
echo "Starting DukenAI. The browser opens by itself."
node server.js
finish
